﻿using Contoso.Models;

namespace Contoso.ViewModels
{
    public class HomeIndexViewModel
    {
        public Contact Contact { get; set; }
        public Customer Customer { get; set; }
    }
}
