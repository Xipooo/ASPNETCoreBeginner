﻿using System;
using System.Collections.Generic;

namespace ContosoRTM.Entities
{
    public partial class DimScenario
    {
        public int ScenarioKey { get; set; }
        public string ScenarioName { get; set; }
    }
}
