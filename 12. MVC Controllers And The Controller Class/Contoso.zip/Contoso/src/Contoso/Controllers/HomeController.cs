﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.Mvc;
using Contoso.Models;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace Contoso.Controllers
{
    //[Route("")]
    //[Route("Home")]
    public class HomeController : Controller
    {
        // GET: /<controller>/
        //[Route("")]
        //[Route("Index")]
        //[Route("Index/{id}")]
        public IActionResult Index(string RedirectUrl)
        {
            return RedirectToRoute(new { controller = "MemberHome", action = "Index" });

            //return Redirect(RedirectUrl);

            //Contact contact = new Contact()
            //{
            //    id = id,
            //    firstName = "Steve",
            //    lastName = "Bishop"
            //};
            //return View(contact);
            //return Content("<html xmlns=\"http://www.w3.org/1999/xhtml\"><head><title>Home</title></head><body>Hi there " + contact.firstName + " " + contact.lastName + "! Your Id is " + contact.id + "</body></html>");
        }

        public IActionResult DownloadData()
        {
            return PhysicalFile("C:\\TestFolder\\TestData.txt", "text/plain");
        }
    }
}
