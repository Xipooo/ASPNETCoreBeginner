﻿using Contoso.Models;
using Contoso.ViewModels;
using Microsoft.AspNet.Mvc;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace Contoso.Controllers
{
    public class HomeController : Controller
    {
        //[HttpGet]
        //public IActionResult IndexWithForm()
        //{
        //    return View("IndexWithForm");
        //}

        [HttpGet]
        public IActionResult Index()
        {
            return View("IndexWithForm");
        }

        [HttpPost]
        public IActionResult Index(Contact contact)
        {
            if (ModelState.IsValid)
            {
                Customer customer = new Customer()
                {
                    Id = 2,
                    CustomerName = "The Company"
                };
                HomeIndexViewModel vm = new HomeIndexViewModel()
                {
                    Contact = contact,
                    Customer = customer
                };

                return View(vm);
            }
            return View("IndexWithForm");

            //Contact contact = new Contact()
            //{
            //    Id = 1,
            //    FirstName = "Steve",
            //    LastName = "Bishop"
            //};
            

        }

        public IActionResult DownloadData()
        {
            return PhysicalFile("C:\\TestFolder\\TestData.txt", "text/plain");
        }
    }
}
