﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace ContosoRTM.Controllers
{
    //[Route("Members/[controller]")]
    [Authorize(Roles = "Member")]
    public class MemberHomeController : Controller
    {
        // GET: /<controller>/
        //[Route("")]
        //[Route("[action]")]
        //[Authorize(Roles = "Member")]
        public IActionResult Index()
        {
            return View();
        }

        //[Authorize(Roles = "Member")]
        //[Route("access")]
        public IActionResult AccessGranted()
        {
            return View();
        }

        [AllowAnonymous]
        public IActionResult AnonymousAccess()
        {
            return View();
        }
    }
}
