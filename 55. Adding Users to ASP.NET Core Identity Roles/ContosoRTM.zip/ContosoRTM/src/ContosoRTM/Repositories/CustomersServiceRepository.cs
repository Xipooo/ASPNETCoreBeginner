﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ContosoRTM.Entities;

namespace ContosoRTM.Repositories
{
    public class CustomersServiceRepository : ICustomersRepository
    {
        public DimCustomer CreateCustomer(DimCustomer newCustomer)
        {
            throw new NotImplementedException();
        }

        public bool DeleteCustomer(int CustomerKey)
        {
            throw new NotImplementedException();
        }

        public ICollection<DimCustomer> GetAllCustomers()
        {
            throw new NotImplementedException();
        }

        public DimCustomer GetCustomer(int CustomerKey)
        {
            throw new NotImplementedException();
        }

        public DimCustomer UpdateCustomer(DimCustomer updatedCustomer)
        {
            throw new NotImplementedException();
        }
    }
}
