﻿using ContosoRTM.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContosoRTM.Repositories
{
    public class CustomersRepository : ICustomersRepository
    {
        private AdventureWorksContext db = new AdventureWorksContext();

        public DimCustomer CreateCustomer(DimCustomer newCustomer)
        {
            db.DimCustomer.Add(newCustomer);
            db.SaveChanges();
            return newCustomer;
        }

        public DimCustomer GetCustomer(int CustomerKey)
        {
            return db.DimCustomer.FirstOrDefault(c => c.CustomerKey == CustomerKey);
        }

        public ICollection<DimCustomer> GetAllCustomers()
        {
            return db.DimCustomer.ToList();
        }

        public DimCustomer UpdateCustomer(DimCustomer updatedCustomer)
        {
            var originalCustomer = db.DimCustomer.FirstOrDefault(c => c.CustomerKey == updatedCustomer.CustomerKey);
            originalCustomer.FirstName = updatedCustomer.FirstName;
            originalCustomer.LastName = updatedCustomer.LastName;
            originalCustomer.Phone = updatedCustomer.Phone;
            originalCustomer.EmailAddress = updatedCustomer.EmailAddress;
            db.SaveChanges();
            return updatedCustomer;
        }

        public bool DeleteCustomer(int CustomerKey)
        {
            DimCustomer deletedCustomer = db.DimCustomer.FirstOrDefault(c => c.CustomerKey == CustomerKey);
            if (deletedCustomer != null)
            {
                db.DimCustomer.Remove(deletedCustomer);
                db.SaveChanges();
                
            }
            return (db.DimCustomer.FirstOrDefault(c => c.CustomerKey == CustomerKey) == null);
        }
    }
}
