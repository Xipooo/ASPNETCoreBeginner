﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ContosoRTM.Entities;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace ContosoRTM.Controllers
{
    public class CustomersController : Controller
    {
        private AdventureWorksContext db = new AdventureWorksContext();

        // GET: /<controller>/
        public IActionResult Index(string CustomerKey)
        {
            var customer = db.DimCustomer.FirstOrDefault(c => c.CustomerAlternateKey == CustomerKey);

            return View(customer);
        }

        public IActionResult CustomerList()
        {
            ICollection<DimCustomer> customers = db.DimCustomer.Where(c => c.CustomerKey > 12000 && c.CustomerKey < 13000).ToList();
            return View(customers);
        }

        public IActionResult Createcustomer()
        {
            DimCustomer newCustomer = new DimCustomer()
            {
                CustomerAlternateKey = "IDontCare",
                Title = "Mr.",
                FirstName = "Tom",
                LastName = "Burke"
            };

            db.DimCustomer.Add(newCustomer);
            db.SaveChanges();

            return RedirectToAction("Index", new { CustomerKey = "IDontCare" });
        }
    }
}
