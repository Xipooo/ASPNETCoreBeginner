﻿using System.Collections.Generic;
using ContosoRTM.Entities;

namespace ContosoRTM.Repositories
{
    public interface ICustomersRepository
    {
        DimCustomer CreateCustomer(DimCustomer newCustomer);
        bool DeleteCustomer(int CustomerKey);
        ICollection<DimCustomer> GetAllCustomers();
        DimCustomer GetCustomer(int CustomerKey);
        DimCustomer UpdateCustomer(DimCustomer updatedCustomer);
    }
}