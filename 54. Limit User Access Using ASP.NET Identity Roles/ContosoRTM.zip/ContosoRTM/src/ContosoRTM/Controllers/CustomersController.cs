﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ContosoRTM.Entities;
using Microsoft.AspNetCore.Diagnostics;
using ContosoRTM.Repositories;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace ContosoRTM.Controllers
{
    public class CustomersController : Controller
    {
        ICustomersRepository repo;

        public CustomersController(ICustomersRepository customersRepository)
        {
            repo = customersRepository;
        }

        // GET: /<controller>/
        public IActionResult GetCustomer(int CustomerKey)
        {
            var customer = repo.GetCustomer(CustomerKey);

            ViewBag.Title = customer.FirstName + " " + customer.LastName;

            return View(customer);
        }

        public IActionResult Index()
        {
            //ViewBag.Title = "Customer List";
            
            return View(repo.GetAllCustomers());
        }

        [HttpGet]
        public IActionResult CreateCustomer()
        {
            var newCustomer = new DimCustomer();
            return View(newCustomer);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CreateCustomer(DimCustomer newCustomer)
        {
            if (ModelState.IsValid)
            {
                newCustomer.CustomerAlternateKey = "AW" + new Random().Next(15000).ToString();
                newCustomer = repo.CreateCustomer(newCustomer);
                return RedirectToAction("GetCustomer", new { CustomerKey = newCustomer.CustomerKey });
            }
            return View("CreatCustomer", newCustomer);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult UpdateCustomer(DimCustomer updatedCustomer)
        {
            if (ModelState.IsValid)
            {
                updatedCustomer = repo.UpdateCustomer(updatedCustomer);
                return RedirectToAction("GetCustomer", new { CustomerKey = updatedCustomer.CustomerKey });
            }
            return View("GetCustomer", updatedCustomer);
        }

        public IActionResult DeleteCustomer(int CustomerKey)
        {
            repo.DeleteCustomer(CustomerKey);
            
            return RedirectToAction("CustomerList");
        }
    }
}
