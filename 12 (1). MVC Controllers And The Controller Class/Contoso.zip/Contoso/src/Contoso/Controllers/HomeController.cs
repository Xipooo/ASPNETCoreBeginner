﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.Mvc;
using Contoso.Models;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace Contoso.Controllers
{
    [Route("")]
    [Route("Home")]
    public class HomeController : Controller
    {
        // GET: /<controller>/
        [Route("")]
        [Route("Index")]
        [Route("Index/{id}")]
        public IActionResult Index(int id)
        {
            //Contact contact = new Contact()
            //{
            //    id = id,
            //    firstName = "Steve",
            //    lastName = "Bishop"
            //};
            ////return View(contact);
            return Content("Hey there gorgeous!");
        }
    }
}
