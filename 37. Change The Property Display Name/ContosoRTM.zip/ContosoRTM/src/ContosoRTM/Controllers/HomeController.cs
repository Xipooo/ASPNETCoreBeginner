﻿using ContosoRTM.Models;
using ContosoRTM.ViewModels;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace ContosoRTM.Controllers
{
    public class HomeController : Controller
    {
        //[HttpGet]
        //public IActionResult IndexWithForm()
        //{
        //    return View("IndexWithForm");
        //}

        [HttpGet]
        public IActionResult Index()
        {
            return View("IndexWithForm");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Index(IndexWithFormViewModel responseVM)
        {
            if (ModelState.IsValid)
            {
                Customer customer = new Customer()
                {
                    Id = 2,
                    CustomerName = "The Company"
                };
                Contact contact = new Contact()
                {
                    Id = (int)responseVM.Id,
                    FirstName = responseVM.FirstName,
                    LastName = responseVM.LastName,
                    PhoneNumber = responseVM.PhoneNumber
                };
                HomeIndexViewModel vm = new HomeIndexViewModel()
                {
                    Contact = contact,
                    Customer = customer
                };

                return View(vm);
            }
            return View("IndexWithForm", responseVM);

            //Contact contact = new Contact()
            //{
            //    Id = 1,
            //    FirstName = "Steve",
            //    LastName = "Bishop"
            //};
            

        }

        public IActionResult DownloadData()
        {
            return PhysicalFile("C:\\TestFolder\\TestData.txt", "text/plain");
        }
    }
}
