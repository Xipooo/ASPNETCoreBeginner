﻿using Contoso.Models;
using Contoso.ViewModels;
using Microsoft.AspNet.Mvc;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace Contoso.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View("IndexWithForm");
        }

        [HttpPost]
        public IActionResult Index(Contact contact)
        {
            //Contact contact = new Contact()
            //{
            //    Id = 1,
            //    FirstName = "Steve",
            //    LastName = "Bishop"
            //};
            Customer customer = new Customer()
            {
                Id = 2,
                CustomerName = "The Company"
            };
            HomeIndexViewModel vm = new HomeIndexViewModel()
            {
                Contact = contact,
                Customer = customer
            };

            return View(vm);
        }
        
        public IActionResult DownloadData()
        {
            return PhysicalFile("C:\\TestFolder\\TestData.txt", "text/plain");
        }
    }
}
