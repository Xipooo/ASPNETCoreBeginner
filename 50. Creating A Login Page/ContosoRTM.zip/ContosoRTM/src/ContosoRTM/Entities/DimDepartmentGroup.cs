﻿using System;
using System.Collections.Generic;

namespace ContosoRTM.Entities
{
    public partial class DimDepartmentGroup
    {
        public int DepartmentGroupKey { get; set; }
        public int? ParentDepartmentGroupKey { get; set; }
        public string DepartmentGroupName { get; set; }

        public virtual DimDepartmentGroup ParentDepartmentGroupKeyNavigation { get; set; }
        public virtual ICollection<DimDepartmentGroup> InverseParentDepartmentGroupKeyNavigation { get; set; }
    }
}
