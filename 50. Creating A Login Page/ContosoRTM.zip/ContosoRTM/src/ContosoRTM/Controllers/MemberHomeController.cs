﻿using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace ContosoRTM.Controllers
{
    //[Route("Members/[controller]")]
    public class MemberHomeController : Controller
    {
        // GET: /<controller>/
        //[Route("")]
        //[Route("[action]")]
        public IActionResult Index()
        {
            return View();
        }

        //[Route("access")]
        public IActionResult AccessGranted()
        {
            return View();
        }

    }
}
