﻿using ContosoRTM.Models;

namespace ContosoRTM.ViewModels
{
    public class HomeIndexViewModel
    {
        public Contact Contact { get; set; }
        public Customer Customer { get; set; }
    }
}
