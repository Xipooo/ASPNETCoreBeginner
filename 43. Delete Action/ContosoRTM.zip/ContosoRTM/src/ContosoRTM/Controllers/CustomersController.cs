﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ContosoRTM.Entities;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.EntityFrameworkCore;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace ContosoRTM.Controllers
{
    public class CustomersController : Controller
    {
        private AdventureWorksContext db = new AdventureWorksContext();

        // GET: /<controller>/
        public IActionResult GetCustomer(int CustomerKey)
        {
            var customer = db.DimCustomer.FirstOrDefault(c => c.CustomerKey == CustomerKey);

            ViewBag.Title = customer.FirstName + " " + customer.LastName;

            return View(customer);
        }

        public IActionResult Index()
        {
            //ViewBag.Title = "Customer List";
            ICollection<DimCustomer> customers = db.DimCustomer.ToList();
            return View(customers);
        }

        [HttpGet]
        public IActionResult CreateCustomer()
        {
            var newCustomer = new DimCustomer();
            return View(newCustomer);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CreateCustomer(DimCustomer newCustomer)
        {
            if (ModelState.IsValid)
            {
                newCustomer.CustomerAlternateKey = "AW" + new Random().Next(15000).ToString();
                db.DimCustomer.Add(newCustomer);
                db.SaveChanges();
                return RedirectToAction("GetCustomer", new { CustomerKey = newCustomer.CustomerKey });
            }
            return View("CreatCustomer", newCustomer);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult UpdateCustomer(DimCustomer updatedCustomer)
        {
            if (ModelState.IsValid)
            {
                var originalCustomer = db.DimCustomer.FirstOrDefault(c => c.CustomerKey == updatedCustomer.CustomerKey);
                originalCustomer.FirstName = updatedCustomer.FirstName;
                originalCustomer.LastName = updatedCustomer.LastName;
                originalCustomer.Phone = updatedCustomer.Phone;
                originalCustomer.EmailAddress = updatedCustomer.EmailAddress;
                db.SaveChanges();
                return RedirectToAction("GetCustomer", new { CustomerKey = updatedCustomer.CustomerKey });
            }
            return View("GetCustomer", updatedCustomer);
        }

        public IActionResult DeleteCustomer(int CustomerKey)
        {
            DimCustomer deletedCustomer = db.DimCustomer
                .Include(i => i.FactSurveyResponse)
                .Include(i => i.FactInternetSales)
                .ThenInclude(i => i.FactInternetSalesReason)
                .FirstOrDefault(c => c.CustomerKey == CustomerKey);
            if (deletedCustomer != null)
            {
                foreach (var factSurveyResponse in deletedCustomer.FactSurveyResponse)
                {
                    db.Remove(factSurveyResponse);
                }
                foreach (var factInternetSale in deletedCustomer.FactInternetSales)
                {
                    foreach (var factInternetSalesReason in factInternetSale.FactInternetSalesReason)
                    {
                        db.Remove(factInternetSalesReason);
                    }
                    db.Remove(factInternetSale);
                }

                db.Remove(deletedCustomer);
                db.SaveChanges();
            }
            return RedirectToAction("Index");
        }
    }
}
