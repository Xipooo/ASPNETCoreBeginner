﻿SELECT *
FROM dbo.DimCustomer
WHERE CustomerAlternateKey = 'IDontCare'