﻿using System;
using System.Collections.Generic;

namespace ContosoRTM.Entities
{
    public partial class FactAdditionalInternationalProductDescription
    {
        public int ProductKey { get; set; }
        public string CultureName { get; set; }
        public string ProductDescription { get; set; }
    }
}
