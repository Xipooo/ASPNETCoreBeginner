﻿using ContosoRTM.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContosoRTM.ViewComponents
{
    public class CustomerInfoViewComponent : ViewComponent
    {
        public async Task<IViewComponentResult> InvokeAsync(int rand)
        {
            AdventureWorksContext context = new AdventureWorksContext();
            //int rand = new Random().Next(11000, 11111);
            var cust = await context.DimCustomer.FirstOrDefaultAsync(c => c.CustomerKey == rand);
            return View(cust);
        }
    }
}
