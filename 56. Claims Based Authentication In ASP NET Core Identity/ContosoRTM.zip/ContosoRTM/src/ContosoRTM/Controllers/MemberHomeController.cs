﻿using ContosoRTM.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System.Security.Claims;
using System.Linq;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace ContosoRTM.Controllers
{
    //[Route("Members/[controller]")]
    //[Authorize(Roles = "Member")]
    public class MemberHomeController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;

        public MemberHomeController(UserManager<ApplicationUser> userManager)
        {
            _userManager = userManager;
        }

        // GET: /<controller>/
        //[Route("")]
        //[Route("[action]")]
        //[Authorize(Roles = "Member")]
        public async Task<IActionResult> Index()
        {
            //var claims = User.Claims;
            var user = await _userManager.FindByNameAsync(User.Identity.Name);
            var storedClaims = await _userManager.GetClaimsAsync(user);
            var claimToRemove = storedClaims.FirstOrDefault(c => c.Type == "First Name");
            //await _userManager.AddClaimAsync(user, new Claim("First Name", "Steve"));
            await _userManager.RemoveClaimAsync(user, claimToRemove);

            var claims = await _userManager.GetClaimsAsync(user);

            return View();
        }

        //[Authorize(Roles = "Member")]
        //[Route("access")]
        public IActionResult AccessGranted()
        {
            return View();
        }

        [AllowAnonymous]
        public IActionResult AnonymousAccess()
        {
            return View();
        }
    }
}
