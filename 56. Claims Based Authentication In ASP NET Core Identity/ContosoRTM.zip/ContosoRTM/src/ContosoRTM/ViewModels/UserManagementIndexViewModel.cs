﻿using ContosoRTM.Models;
using System.Collections.Generic;

namespace ContosoRTM.ViewModels
{
    public class UserManagementIndexViewModel
    {
        public List<ApplicationUser> Users { get; set; }
    }
}
